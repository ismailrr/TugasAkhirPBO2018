/**
* Kelas componentTitik ini extends JButton supaya objeknya bisa diklik
* 1 objek dari kelas ini me-presentasikan 1 buah titik dari banyak titik di papan
**/

import java.awt.*;
import javax.swing.*;

class ComponentTitik extends JButton {
	private Papan papan;
	private int row; //posisi baris titik
	private int col; //posisi kolom titik

	public ComponentTitik(Papan papan,int row,int col) {
		this.papan = papan;
		this.row = row;
		this.col = col;

	}

	//TODO: bikin method setter getter instance variable

	/* paintComponent merupakan override method
	   setiap component mempunyai method paintComponent yang berfungsi segabai alat si javanya menggambar*/
	public void paintComponent(Graphics g) {

		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;

		// mengambil ukuran grid 1x1
		int w = super.getWidth();
		int h = super.getHeight();
		
		//jika ternyata pada titik row,col di papan masih kosong, tidak perlu menggambar oval
		if(papan.getTitik(row,col) == ' ') //char ' ' mempresentasikan titik Kosong/belum diisi
			return;

		//TODO : buat statement yang membedakan apakah titik yang akan digambar warna putih,atau warna hitam
		//hint : kelas Graphics punya method setColor()

		//fillOval(x,y,w,h) untuk mewarna bentuk oval dengan posisi x,y dengan ukuran w,h
		g2.fillOval(0,0,w,h);
	}
}