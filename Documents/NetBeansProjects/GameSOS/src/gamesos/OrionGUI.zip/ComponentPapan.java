/**
* kelas ini buat jadi Panel grid untuk titik-titiknya yang akan digambar
* tujuannya supaya lebih mudah menggambar titik2nya dan rapih
* panelnya juga langsung mengikuti ukuran frame yang telah diset di kelas Driver
**/
import java.awt.*;
import javax.swing.*;

class ComponentPapan extends JPanel {
	private Papan papan;
	private int row;
	private int col;

	public ComponentPapan(Papan papan,int row,int col) {
		this.papan = papan;
		this.row = row;
		this.col = col;

		//TODO : set layout Jpanel ini dengan grid berukuran row * col
		setLayout(/* isi */);

		/* jadi, setiap titik punya tukang gambar yang bernama ComponentTitik. kemudian ComponentTitik tersebut dimasukkan kedalam grid ComponentPapan */
		Controller controller = new Controller(papan);
		for(int i = 0; i<row; i++)
			for(int j = 0; j<col; j++) {
				ComponentTitik tmp = new ComponentTitik(papan,i,j);
				// memberikan Listener ke setiap titik, supaya kalo titiknya diteken akan men-trigger controllernya
				tmp.addActionListener(controller);
				// memasukkan componentTitik tmp ke dalam grid, dan dimasukkan terurut dari atas kiri ke kanan bawah grid secara auto
				// jadi tinggal add, si objeknya bakal ngisi ke grid paling atas terkiri yang masih kosong
				add(tmp);
			}
	}
}