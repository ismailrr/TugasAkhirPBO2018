import java.awt.*;
import javax.swing.*;

/**
*  kelas Driver merupakan main class yang bakal membuat sekaligus mengisi frame dengan objek-objek yang
*  telah dibuat nantinya
*  @author ?
**/

public class Driver {

	public static void main(String args[]) {
		
		JFrame frame = new JFrame("GUI");

		frame.setLayout(new BorderLayout());
		frame.add(componentPapan); //TODO : hilangkan errornya
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(/* isi */); // untuk nge-set ukuran dari frame, contoh : frame.setSize(400,400);
		frame.setVisible(true); // frame yang dibuat defaultnya belum ditampilkan, oleh karena itu harus diset visible
	}
}