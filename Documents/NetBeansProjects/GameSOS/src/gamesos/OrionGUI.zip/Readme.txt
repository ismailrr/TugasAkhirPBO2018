demi ketenangan dan biar bisa fokus UAS, gue buat :
Template untuk membantu mengerjakan Tugas 3 DDP

template ini dibuat untuk yg masih bingung dengan GUI.

kalo udah ngerjain ini, fiturnya baru sampai ngecek menang.
jadi untuk fitur seperti tombol restart, tombol quit, tinggal tambahin aja.
oh iya GUInya juga masih apa adanya. coba manfaatkan method2 keren di kelas Graphics2D :)
ada juga kelas JLabel buat nampilin teks.

motivasi : ada gambar difolder ini, kalo kepo liat aja. karena Java dewa, tukang gambar Java juga bisa "gambar" gambar (?)

kalo ada yang mau ditanyain, mawan sama udin bersedia katanya wkwk

Selamat mengerjakan, semoga membantu ya
