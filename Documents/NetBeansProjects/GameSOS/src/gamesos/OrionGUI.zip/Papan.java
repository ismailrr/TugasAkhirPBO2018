/**
* Kelas papan merupakan kelas yang menyimpan informasi/kondisi papan, kelas ini bukan merupakan kelas yang mencetak wujud papannya
**/

class Papan {
	//TODO : variabel-variabel yang dibutuhkan

	public Papan(int row,int col) {
		this.row = row;
		this.col = col;
		papan = new char[row][col];

		resetPapan();
	}

	public void resetPapan() {
		for(int i = 0; i<row; i++) {
			for(int j = 0; j<col; j++) {
				setTitik(i,j,' '); // meng-kosongkan papan
			}
		}
	}

	public char[][] getPapan() {
		return papan;
	}

	public void setPapan(char[][] papan) {
		this.papan = papan;
	}

	public char getTitik(int row,int col) {
		return papan[row][col];
	}

	public void setTitik(int row,int col,char color) {
		papan[row][col] = color;
	}
}