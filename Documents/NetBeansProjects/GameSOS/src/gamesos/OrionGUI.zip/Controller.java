/**
* kelas ini merupakan kelas yang menjadi controller pada game, dimana kelas ini akan menerima masukan dari klik mouse user
* dengan me-implements ActionListener, maka void actionPerformed harus ada pada kelas ini
* ActionPerformed yang akan melakukan respon untuk mouse klik user
**/

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;

class Controller implements ActionListener {
	private Papan papan;
	private char color;

	public Controller(Papan papan) {
		this.papan = papan;
		color = 'B';
	}

	public void actionPerformed(ActionEvent e) {
		/* ActionEvent e merupakan objek yang telah ditrigger dengan klik mouse 
		   jadi kita bisa mengakses ComponentTitik yang mana yang diklik dengan casting terlebih dahulu*/
		ComponentTitik tmp = (ComponentTitik) e.getSource();

		if(papan.getTitik(tmp.getRow(),tmp.getCol()) == ' ') {
			papan.setTitik(tmp.getRow(),tmp.getCol(),color);

			//cek pemenang setelah menaruh bidak pada titik
			checkWinner(tmp.getRow(),tmp.getCol());			

			//untuk pergantian sesi pemain, jika color == 'B' maka color = 'W', sebaliknya
			color = color == 'B' ? 'W' : 'B';
		}
	}

	public void checkWinner(int row,int col) {
		//TODO: cek apakah sudah ada yang menang
		
		//jika menang, maka menampilkan Message menggunakan JOptionPane.showMessageDialog.
		//bisa juga menampilkan dengan alternatif lain
		//contoh : JOptionPane.showMessageDialog("YES! " + (color == 'B' ? "HITAM" : "PUTIH") + " MENANG!!!");
	}
}